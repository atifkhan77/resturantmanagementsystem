/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.resturantmanagementsystem;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author abdullaalameri
 */
public class Customer {
    public String adress;
    public String name;
       public static  int orderid;
       public static int customerorderindex;

    Customer(String name, String address){
        this.adress = address;
        this.name = name;
    }
}
