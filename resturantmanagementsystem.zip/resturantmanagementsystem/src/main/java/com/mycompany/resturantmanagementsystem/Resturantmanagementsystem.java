/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.resturantmanagementsystem;

//import mainform;

/**
 *
 * @author raoaw
 */
public class Resturantmanagementsystem {

    public static void main(String[] args) {
        Menu menu = new Menu();
        Dish d1 = new maincourse(1,"Chicken Majbous",84);
        Dish d2 = new maincourse(2,"Lamb Majbous",61);
        Dish d3 = new maincourse(3,"Hammour Majobous",50);
        Dish d4 = new maincourse(4,"Fish Majobous",74);
        Dish d5 = new maincourse(5,"Maleh Mtabban",61);
        Dish d6 = new maincourse(6,"Sweet rice",53);
        Dish d7 = new maincourse(7,"Chicken biryani",78);
        Dish d8 = new maincourse(8,"Meat biryani",53);
        Dish d9 = new maincourse(9,"King fish biryani",47);
        Dish d10 = new maincourse(10,"Shrimp Biryani",90);
        Dish d11 = new maincourse(11,"Jasheed",50);
        Dish d12 = new maincourse(12,"Huboui",53);
        Dish d13 = new maincourse(13,"Harees Meat",70);
            appetizer a1 = new appetizer(14,"Dates",10);
            appetizer a2 = new appetizer(15,"Coke",5);
            appetizer a3 = new appetizer(16,"Garlic bread",7);
            appetizer a4 = new appetizer(17,"Sprite",5);
            appetizer a5 = new appetizer(18,"Lemonade",2);
                        desert de1 = new desert(19,"Liqaimat",5);
                        desert de2 = new desert(20,"Khabees",7);
                        desert de3 = new desert(21,"Gebab",9);
                        desert de4 = new desert(22,"Porridge",3);
  

        menu.add(d1);
        menu.add(d2);
        menu.add(d3);
        menu.add(d4);
        menu.add(d5);
        menu.add(d6);
        menu.add(d7);
        menu.add(d8);
        menu.add(d9);
        menu.add(d10);
        menu.add(d11);
        menu.add(d12);
        menu.add(d13);
        menu.add(a1);
        menu.add(a2);
        menu.add(a3);
        menu.add(a4);
        menu.add(a5);
        menu.add(de1);
        menu.add(de2);
        menu.add(de3);
        menu.add(de4);

        mainform.mainf();
      
    }
}
