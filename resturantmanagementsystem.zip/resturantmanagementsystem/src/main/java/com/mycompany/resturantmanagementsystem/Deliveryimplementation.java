/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.resturantmanagementsystem;


/**
 *
 * @author abdullaalameri
 */
public class Deliveryimplementation {

    protected int ID;
    public String name;
    public String date;
    public String adress;
    public int payment;
    
    Deliveryimplementation(int id, String n, String d, String a,int p){
        this.ID = id;
        this.name = n;
        this.date = d;
        this.adress = a;
        this.payment = p;
        
    }

    public void update() {
        
    }

}

