/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.resturantmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author abdullaalameri
 */
public class Payment {

    public int ID;
    public String car_num;
     ArrayList<Integer> pricesofallthedishesintheorder =  new ArrayList<Integer>();
    public String amount;

    public void add(int price) {
        pricesofallthedishesintheorder.add(price);
    }

    public int calculatebill(ArrayList<Integer> prices) {
        int totalprice = 0;
        for(int i = 0 ; i<prices.size(); i++){
            totalprice = totalprice + prices.get(i);
        }
        return totalprice;
    }

}
