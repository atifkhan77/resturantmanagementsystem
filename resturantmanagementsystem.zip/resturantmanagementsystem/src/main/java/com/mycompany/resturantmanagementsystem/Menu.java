/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.resturantmanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author abdullaalameri
 */
public class Menu {

    public String details;
     static ArrayList<Dish> listofdishes = new ArrayList<Dish>();

    public void add(Dish d) {
            listofdishes.add(d);
    }

}
