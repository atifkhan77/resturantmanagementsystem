/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.resturantmanagementsystem;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;

/**
 *
 * @author abdullaalameri
 */
public class Order {

    protected int ID;
    ArrayList<Dish> detailsoforder =  new ArrayList<Dish>();
    
    Order(int id){
        this.ID = id;
    }
    

}
